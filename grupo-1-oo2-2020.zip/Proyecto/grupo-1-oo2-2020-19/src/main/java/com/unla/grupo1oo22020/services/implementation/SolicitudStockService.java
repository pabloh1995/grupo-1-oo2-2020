package com.unla.grupo1oo22020.services.implementation;

public class SolicitudStockService {

}
