package com.unla.grupo1oo22020;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Grupo1Oo22020ApplicationTests {

	//@Test
	void contextLoads() {
	}

}
