package com.unla.grupo1oo22020.entities;

import java.time.LocalTime;

import com.unla.grupo1oo22020.models.LocalModel;

public class Empleado {
	private long idEmpleado;
	private float sueldoBasico;
	private LocalTime horarioTrabajoE;
	private LocalTime horarioTrabajoS;
	private boolean gerente;
	private LocalModel local;

	public Empleado() {
	}

	
	public long getId() {
		return idEmpleado;
	}

	protected void setId(int idEmpleado) {
		this.idEmpleado = idEmpleado;
	}

	public float getSueldoBasico() {
		return sueldoBasico;
	}

	public void setSueldoBasico(float sueldoBasico) {
		this.sueldoBasico = sueldoBasico;
	}

	public LocalTime getHorarioTrabajoE() {
		return horarioTrabajoE;
	}

	public void setHorarioTrabajoE(LocalTime horarioTrabajoE) {
		this.horarioTrabajoE = horarioTrabajoE;
	}

	public LocalTime getHorarioTrabajoS() {
		return horarioTrabajoS;
	}

	public void setHorarioTrabajoS(LocalTime horarioTrabajoS) {
		this.horarioTrabajoS = horarioTrabajoS;
	}

	public boolean isGerente() {
		return gerente;
	}

	public void setGerente(boolean gerente) {
		this.gerente = gerente;
	}

	public LocalModel getLocal() {
		return local;
	}

	public void setLocal(LocalModel local) {
		this.local = local;
	}

}
