package com.unla.grupo1oo22020.entities;

public class Local {

}
