package com.unla.grupo1oo22020.entities;

import javax.persistence.Entity;

@Entity
public class Cliente extends Persona {
	
	
	private long idCliente;
	private String email;

	public Cliente() {
	}

	
	public long getIdCliente() {
		return idCliente;
	}

	public void setIdCliente(int idCliente) {
		this.idCliente = idCliente;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}


}