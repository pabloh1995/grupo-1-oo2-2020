package com.unla.grupo1oo22020.helpers;

public class ViewRouteHelpers {
	/**** Views ****/
	//HOME
	public final static String INDEX = "home/index";
	
	//CLIENTE
	public final static String CLIENTE_INDEX = "cliente/index";
	public final static String CLIENTE_ADD = "cliente/add";
	public final static String CLIENTE_NEW = "cliente/new";
	
	//EMPLEADO
	public final static String EMPLEADO_INDEX = "empleado/index";
	public final static String EMPLEADO_ADD = "empleado/add";
	public final static String EMPLEADO_NEW = "empleado/new";

	//PERSONA
	public final static String PERSONA_INDEX = "persona/index";
	public final static String PERSONA_ADD = "persona/add";
	public final static String PERSONA_NEW = "persona/new";
	
	//DETALLEVENTA
	public final static String DETALLEVENTA_INDEX = "detalleventa/index";
	public final static String DETALLEVENTA_ADD = "detalleventa/add";
	public final static String DETALLEVENTA_NEW = "detalleventa/new";
	
	//LOCAL
	public final static String LOCAL_INDEX = "local/index";
	public final static String LOCAL_ADD = "local/add";
	public final static String LOCAL_NEW = "local/new";
	
	//LOTE
	public final static String LOTE_INDEX = "lote/index";
	public final static String LOTE_ADD = "lote/add";
	public final static String LOTE_NEW = "lote/new";
	
	//PRODUCTO
	public final static String PRODUCTO_INDEX = "producto/index";
	public final static String PRODUCTO_ADD = "producto/add";
	public final static String PRODUCTO_NEW = "producto/new";
	
	//SOLICITUDSTOCK
	public final static String SOLICITUDSTOCK_INDEX = "solicitudstock/index";
	public final static String SOLICITUDSTOCK_ADD = "solicitudstock/add";
	public final static String SOLICITUDSTOCK_NEW = "solicitudstock/new";
	
	//VENTA
	public final static String VENTA_INDEX = "venta/index";
	public final static String VENTA_ADD = "venta/add";
	public final static String VENTA_NEW = "venta/new";
	
	/**** Redirects ****/
	public final static String ROUTE_INDEX = "/index";
	public final static String CLIENTE_ROOT = "/clientes";
	public final static String EMPLEADO_ROOT="/empleados";
	public final static String PERSONA_ROOT="/personas";
	public final static String DETALLEVENTA_ROOT="/detalleventas";
	public final static String LOCAL_ROOT = "/locales";
	public final static String LOTE_ROOT="/lotes";
	public final static String PRODUCTO_ROOT = "/productos";
	public final static String SOLICITUDSTOCK_ROOT = "/solicitudstocks";
	public final static String VENTA_ROOT = "/ventas";

}
