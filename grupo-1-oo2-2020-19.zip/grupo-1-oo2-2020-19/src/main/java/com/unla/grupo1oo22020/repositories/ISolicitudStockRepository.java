package com.unla.grupo1oo22020.repositories;

public interface ISolicitudStockRepository {

}
