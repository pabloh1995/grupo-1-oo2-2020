package com.unla.grupo1oo22020.controllers;

public class SolicitudStockController {

}
