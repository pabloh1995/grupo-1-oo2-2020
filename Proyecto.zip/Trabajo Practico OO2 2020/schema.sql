create schema `grupo-1-bdd-oo2-2020`;
use `grupo-1-bdd-oo2-2020`;